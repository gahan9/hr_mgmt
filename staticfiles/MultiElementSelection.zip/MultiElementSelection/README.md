
Multi-Item Selection
=========

Ever thought that clicking multiple checkboxes is not a very user-friendly task? Imagine rows and rows of junk mail that you'd like to select in your email app. This little script tries to ease that task by allowing a rapid and simple selection of multiple items by clicking, holding and moving over the desired items.

[Article on Codrops](http://tympanus.net/codrops/?p=16730)

[Demo](http://tympanus.net/Development/MultiElementSelection/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)